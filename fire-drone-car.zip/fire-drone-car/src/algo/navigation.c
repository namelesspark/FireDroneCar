#include <stdio.h>
#include <stdlib.h>
#include "navigation.h"

void auto_navigate();